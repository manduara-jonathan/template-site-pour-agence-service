import Image from "next/image"
import Link from "next/link"
import { ArrowRight, ExternalLink } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PortfolioPage() {
  const projects = [
    {
      id: 1,
      title: "E-commerce Luxe",
      client: "Maison Élégance",
      category: "e-commerce",
      description:
        "Boutique en ligne haut de gamme avec expérience utilisateur personnalisée et système de paiement sécurisé.",
      results: "Augmentation des ventes de 200% en 6 mois, taux de conversion amélioré de 15%.",
      image:
        "https://images.unsplash.com/photo-1607082349566-187342175e2f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 2,
      title: "Application Mobile Fitness",
      client: "FitLife",
      category: "mobile",
      description:
        "Application de suivi fitness avec plans d'entraînement personnalisés, suivi nutritionnel et communauté intégrée.",
      results: "Plus de 100 000 téléchargements en 3 mois, note moyenne de 4.8/5 sur les stores.",
      image:
        "https://images.unsplash.com/photo-1605296867304-46d5465a13f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 3,
      title: "Plateforme Éducative",
      client: "EduConnect",
      category: "web",
      description:
        "Plateforme d'apprentissage en ligne avec cours interactifs, système de progression et tableau de bord analytique.",
      results: "50 000 utilisateurs actifs mensuels, taux de complétion des cours de 78%.",
      image:
        "https://images.unsplash.com/photo-1610484826967-09c5720778c7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 4,
      title: "Campagne SEO Immobilier",
      client: "ImmoPlus",
      category: "marketing",
      description:
        "Stratégie SEO complète avec optimisation technique, création de contenu et netlinking pour une agence immobilière.",
      results: "Augmentation du trafic organique de 350%, positionnement en 1ère page pour 45 mots-clés stratégiques.",
      image:
        "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 5,
      title: "CRM Sur-mesure",
      client: "TechSolutions",
      category: "software",
      description:
        "Développement d'un CRM personnalisé intégrant gestion des leads, suivi des opportunités et reporting avancé.",
      results: "Réduction de 40% du temps de gestion commerciale, augmentation des conversions de 25%.",
      image:
        "https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 6,
      title: "Refonte Site Corporate",
      client: "IndustriaGroup",
      category: "web",
      description:
        "Refonte complète du site corporate avec design moderne, optimisation UX et intégration multilingue.",
      results: "Réduction du taux de rebond de 60%, augmentation du temps moyen passé sur le site de 2 minutes.",
      image:
        "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 7,
      title: "Campagne Social Media",
      client: "ModaBrand",
      category: "marketing",
      description:
        "Stratégie social media avec création de contenu, community management et campagnes publicitaires ciblées.",
      results: "Croissance de la communauté de 300%, engagement moyen par post augmenté de 45%.",
      image:
        "https://images.unsplash.com/photo-1611926653458-09294b3142bf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 8,
      title: "Application Web Comptable",
      client: "ComptaFacile",
      category: "software",
      description:
        "Application web de gestion comptable avec facturation automatisée, suivi de trésorerie et reporting fiscal.",
      results: "Économie de 15 heures par mois pour les utilisateurs, conformité fiscale améliorée de 100%.",
      image:
        "https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 9,
      title: "E-commerce Dropshipping",
      client: "GlobalShop",
      category: "e-commerce",
      description:
        "Boutique e-commerce en dropshipping avec intégration fournisseurs, automatisation des commandes et suivi logistique.",
      results: "Marge bénéficiaire augmentée de 18%, temps de traitement des commandes réduit de 65%.",
      image:
        "https://images.unsplash.com/photo-1565084888279-aca607ecce0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/90 to-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px] opacity-10"></div>
        <div className="container px-4 md:px-6 relative z-10">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white">
                Notre Portfolio
              </h1>
              <p className="max-w-[600px] text-white md:text-xl">
                Découvrez nos réalisations et les résultats concrets que nous avons obtenus pour nos clients.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="grid grid-cols-3 md:grid-cols-6 w-full max-w-3xl">
                <TabsTrigger value="all">Tous</TabsTrigger>
                <TabsTrigger value="web">Web</TabsTrigger>
                <TabsTrigger value="e-commerce">E-commerce</TabsTrigger>
                <TabsTrigger value="mobile">Mobile</TabsTrigger>
                <TabsTrigger value="marketing">Marketing</TabsTrigger>
                <TabsTrigger value="software">Logiciel</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {projects.map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
              </div>
            </TabsContent>
            {["web", "e-commerce", "mobile", "marketing", "software"].map((category) => (
              <TabsContent key={category} value={category} className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {projects
                    .filter((project) => project.category === category)
                    .map((project) => (
                      <ProjectCard key={project.id} project={project} />
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* Case Studies Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">Études de Cas</div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Résultats Concrets</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Découvrez en détail comment nous avons aidé nos clients à atteindre leurs objectifs.
              </p>
            </div>
          </div>
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            {projects.slice(0, 2).map((project) => (
              <Card key={project.id} className="overflow-hidden">
                <div className="aspect-video relative">
                  <Image src={project.image || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle>{project.title}</CardTitle>
                  <CardDescription>Client: {project.client}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold">Le défi</h3>
                      <p className="text-muted-foreground">{project.description}</p>
                    </div>
                    <div>
                      <h3 className="font-semibold">Notre approche</h3>
                      <p className="text-muted-foreground">
                        Nous avons mis en place une stratégie personnalisée basée sur une analyse approfondie des
                        besoins du client et des meilleures pratiques du secteur.
                      </p>
                    </div>
                    <div>
                      <h3 className="font-semibold">Résultats</h3>
                      <p className="text-muted-foreground">{project.results}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline">
                    <Link href={`/portfolio/${project.id}`}>
                      Voir l'étude de cas complète <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
          <div className="flex justify-center mt-12">
            <Button asChild>
              <Link href="/case-studies">
                Voir toutes nos études de cas <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Prêt à lancer votre projet?
              </h2>
              <p className="mx-auto max-w-[700px] text-primary-foreground/80 md:text-xl">
                Contactez-nous dès aujourd'hui pour discuter de votre projet et découvrir comment nous pouvons vous
                aider à atteindre vos objectifs.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild size="lg" variant="secondary">
                <Link href="/devis">
                  Demander un devis <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

function ProjectCard({ project }: { project: any }) {
  return (
    <Card className="overflow-hidden group">
      <div className="aspect-video relative overflow-hidden">
        <Image
          src={project.image || "/placeholder.svg"}
          alt={project.title}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{project.title}</CardTitle>
            <CardDescription>Client: {project.client}</CardDescription>
          </div>
          <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary text-primary-foreground hover:bg-primary/80">
            {project.category.charAt(0).toUpperCase() + project.category.slice(1)}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground line-clamp-3">{project.description}</p>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button asChild variant="outline" size="sm">
          <Link href={`/portfolio/${project.id}`}>Voir le projet</Link>
        </Button>
        <Button asChild variant="ghost" size="icon">
          <Link href="#" aria-label="Voir le site">
            <ExternalLink className="h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

