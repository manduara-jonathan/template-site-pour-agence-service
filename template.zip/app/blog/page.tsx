import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Calendar, Clock, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function BlogPage() {
  const posts = [
    {
      id: 1,
      title: "10 tendances du marketing digital à suivre en 2023",
      excerpt:
        "Découvrez les tendances qui façonneront le paysage du marketing digital cette année et comment les intégrer à votre stratégie.",
      category: "marketing",
      author: "Sophie Dubois",
      date: "15 juin 2023",
      readTime: "8 min",
      image:
        "https://images.unsplash.com/photo-1533750349088-cd871a92f312?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 2,
      title: "Comment optimiser la vitesse de chargement de votre site web",
      excerpt:
        "La vitesse de chargement est un facteur crucial pour l'expérience utilisateur et le référencement. Voici nos conseils pour l'améliorer.",
      category: "web",
      author: "Alexandre Chen",
      date: "2 juin 2023",
      readTime: "6 min",
      image:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 3,
      title: "Les meilleures pratiques pour le développement d'applications mobiles en 2023",
      excerpt:
        "De la conception à la publication, découvrez les meilleures pratiques pour créer des applications mobiles performantes et engageantes.",
      category: "mobile",
      author: "Lucas Petit",
      date: "28 mai 2023",
      readTime: "10 min",
      image:
        "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 4,
      title: "Comment mettre en place une stratégie de contenu efficace",
      excerpt:
        "Le contenu est roi, mais encore faut-il savoir comment l'utiliser efficacement. Découvrez nos conseils pour une stratégie de contenu gagnante.",
      category: "marketing",
      author: "Marie Leroy",
      date: "15 mai 2023",
      readTime: "7 min",
      image:
        "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 5,
      title: "Les fondamentaux du SEO technique pour les développeurs",
      excerpt:
        "Un guide complet des aspects techniques du SEO que tout développeur devrait connaître pour créer des sites web bien référencés.",
      category: "web",
      author: "Thomas Martin",
      date: "5 mai 2023",
      readTime: "12 min",
      image:
        "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 6,
      title: "Comment choisir le bon CMS pour votre projet web",
      excerpt:
        "WordPress, Drupal, Joomla... Comment choisir la plateforme qui correspond le mieux à vos besoins? Notre guide comparatif.",
      category: "web",
      author: "Camille Bernard",
      date: "28 avril 2023",
      readTime: "9 min",
      image:
        "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 7,
      title: "L'importance de l'UX design dans la conversion",
      excerpt:
        "Comment un bon design d'expérience utilisateur peut significativement améliorer vos taux de conversion et fidéliser vos clients.",
      category: "design",
      author: "Marie Leroy",
      date: "20 avril 2023",
      readTime: "8 min",
      image:
        "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 8,
      title: "Les bases de la cybersécurité pour votre entreprise",
      excerpt:
        "Protégez votre entreprise des menaces en ligne avec ces conseils essentiels de cybersécurité adaptés aux PME.",
      category: "security",
      author: "David Moreau",
      date: "12 avril 2023",
      readTime: "11 min",
      image:
        "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
    {
      id: 9,
      title: "Comment utiliser l'IA dans votre stratégie marketing",
      excerpt:
        "L'intelligence artificielle révolutionne le marketing. Découvrez comment l'intégrer à votre stratégie pour des résultats optimaux.",
      category: "marketing",
      author: "Sophie Dubois",
      date: "5 avril 2023",
      readTime: "10 min",
      image:
        "https://images.unsplash.com/photo-1677442135136-760c813a743d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/90 to-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px] opacity-10"></div>
        <div className="container px-4 md:px-6 relative z-10">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white">
                Notre Blog
              </h1>
              <p className="max-w-[600px] text-white md:text-xl">
                Actualités, conseils et tendances du monde digital pour vous aider à développer votre présence en ligne.
              </p>
            </div>
            <div className="w-full max-w-md">
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Rechercher un article..."
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/60 pr-10"
                />
                <Button variant="ghost" size="icon" className="absolute right-0 top-0 h-full text-white">
                  <ArrowRight className="h-4 w-4" />
                  <span className="sr-only">Rechercher</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="grid grid-cols-3 md:grid-cols-6 w-full max-w-3xl">
                <TabsTrigger value="all">Tous</TabsTrigger>
                <TabsTrigger value="marketing">Marketing</TabsTrigger>
                <TabsTrigger value="web">Web</TabsTrigger>
                <TabsTrigger value="mobile">Mobile</TabsTrigger>
                <TabsTrigger value="design">Design</TabsTrigger>
                <TabsTrigger value="security">Sécurité</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {posts.map((post) => (
                  <BlogCard key={post.id} post={post} />
                ))}
              </div>
            </TabsContent>
            {["marketing", "web", "mobile", "design", "security"].map((category) => (
              <TabsContent key={category} value={category} className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {posts
                    .filter((post) => post.category === category)
                    .map((post) => (
                      <BlogCard key={post.id} post={post} />
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
          <div className="flex justify-center mt-12">
            <Button variant="outline">Charger plus d'articles</Button>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">À la Une</div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Articles Populaires</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Découvrez nos articles les plus lus et partagés.
              </p>
            </div>
          </div>
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            {posts.slice(0, 2).map((post) => (
              <Card key={post.id} className="overflow-hidden">
                <div className="aspect-video relative">
                  <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                    <span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary text-primary-foreground hover:bg-primary/80">
                      {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
                    </span>
                    <span className="flex items-center">
                      <Calendar className="mr-1 h-3 w-3" />
                      {post.date}
                    </span>
                    <span className="flex items-center">
                      <Clock className="mr-1 h-3 w-3" />
                      {post.readTime}
                    </span>
                  </div>
                  <CardTitle className="text-2xl">{post.title}</CardTitle>
                  <CardDescription className="text-base">{post.excerpt}</CardDescription>
                </CardHeader>
                <CardFooter className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="rounded-full bg-muted p-1 mr-2">
                      <User className="h-4 w-4" />
                    </div>
                    <span className="text-sm">{post.author}</span>
                  </div>
                  <Button asChild>
                    <Link href={`/blog/${post.id}`}>Lire l'article</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Restez informé</h2>
              <p className="mx-auto max-w-[700px] text-primary-foreground/80 md:text-xl">
                Abonnez-vous à notre newsletter pour recevoir nos derniers articles et conseils directement dans votre
                boîte mail.
              </p>
            </div>
            <div className="w-full max-w-md">
              <form className="flex space-x-2">
                <Input
                  type="email"
                  placeholder="Votre adresse email"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/60 flex-1"
                  required
                />
                <Button type="submit" variant="secondary">
                  S'abonner
                </Button>
              </form>
              <p className="mt-2 text-sm text-primary-foreground/60">
                Nous respectons votre vie privée. Désabonnez-vous à tout moment.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

function BlogCard({ post }: { post: any }) {
  return (
    <Card className="overflow-hidden h-full flex flex-col">
      <div className="aspect-video relative">
        <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
      </div>
      <CardHeader className="flex-1">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
          <span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary text-primary-foreground hover:bg-primary/80">
            {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
          </span>
          <span className="flex items-center">
            <Calendar className="mr-1 h-3 w-3" />
            {post.date}
          </span>
        </div>
        <CardTitle>{post.title}</CardTitle>
        <CardDescription className="line-clamp-3">{post.excerpt}</CardDescription>
      </CardHeader>
      <CardFooter className="flex justify-between items-center border-t pt-4">
        <div className="flex items-center">
          <div className="rounded-full bg-muted p-1 mr-2">
            <User className="h-4 w-4" />
          </div>
          <span className="text-sm">{post.author}</span>
        </div>
        <div className="flex items-center text-sm text-muted-foreground">
          <Clock className="mr-1 h-3 w-3" />
          {post.readTime}
        </div>
      </CardFooter>
    </Card>
  )
}

