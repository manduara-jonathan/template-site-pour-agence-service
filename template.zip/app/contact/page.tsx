"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Mail, MapPin, Phone } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setIsSuccess(true)
    setFormData({
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    })

    // Reset success message after 5 seconds
    setTimeout(() => setIsSuccess(false), 5000)
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/90 to-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px] opacity-10"></div>
        <div className="container px-4 md:px-6 relative z-10">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white">
                Contactez-nous
              </h1>
              <p className="max-w-[600px] text-white md:text-xl">
                Nous sommes à votre écoute pour discuter de vos projets et vous accompagner dans votre transformation
                digitale.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="space-y-8">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter">Parlons de votre projet</h2>
                <p className="text-muted-foreground">
                  Remplissez le formulaire ci-dessous et nous vous répondrons dans les plus brefs délais.
                </p>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nom complet</Label>
                    <Input
                      id="name"
                      name="name"
                      placeholder="Votre nom"
                      required
                      value={formData.name}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      placeholder="Votre email"
                      required
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input
                      id="phone"
                      name="phone"
                      placeholder="Votre téléphone"
                      value={formData.phone}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Sujet</Label>
                    <Input
                      id="subject"
                      name="subject"
                      placeholder="Sujet de votre message"
                      required
                      value={formData.subject}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">Message</Label>
                  <Textarea
                    id="message"
                    name="message"
                    placeholder="Décrivez votre projet ou votre demande"
                    required
                    className="min-h-[150px]"
                    value={formData.message}
                    onChange={handleChange}
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? "Envoi en cours..." : "Envoyer le message"}
                </Button>
                {isSuccess && (
                  <div className="rounded-lg bg-green-50 p-4 text-green-600 text-sm">
                    Votre message a été envoyé avec succès. Nous vous répondrons dans les plus brefs délais.
                  </div>
                )}
              </form>
            </div>
            <div className="space-y-8">
              <Tabs defaultValue="contact" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="contact">Coordonnées</TabsTrigger>
                  <TabsTrigger value="faq">FAQ</TabsTrigger>
                </TabsList>
                <TabsContent value="contact" className="space-y-4 pt-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Nos coordonnées</CardTitle>
                      <CardDescription>Plusieurs façons de nous contacter</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-start space-x-4">
                        <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                        <div>
                          <h3 className="font-semibold">Adresse</h3>
                          <p className="text-muted-foreground">
                            25 Avenue Mikeno, Quartier Les Volcans, Goma, Nord-Kivu, RDC
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-4">
                        <Phone className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                        <div>
                          <h3 className="font-semibold">Téléphone</h3>
                          <p className="text-muted-foreground">
                            <Link href="tel:+243970123456" className="hover:underline">
                              +243 970 123 456
                            </Link>
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-4">
                        <Mail className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                        <div>
                          <h3 className="font-semibold">Email</h3>
                          <p className="text-muted-foreground">
                            <Link href="mailto:contact@g3m-technology.com" className="hover:underline">
                              contact@g3m-technology.com
                            </Link>
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Horaires d'ouverture</CardTitle>
                      <CardDescription>Nous sommes disponibles pour vous aider</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="font-semibold">Lundi - Vendredi</p>
                          <p className="text-muted-foreground">9h00 - 18h00</p>
                        </div>
                        <div>
                          <p className="font-semibold">Samedi</p>
                          <p className="text-muted-foreground">10h00 - 15h00</p>
                        </div>
                        <div className="col-span-2">
                          <p className="font-semibold">Dimanche</p>
                          <p className="text-muted-foreground">Fermé</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="faq" className="space-y-4 pt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Questions fréquentes</CardTitle>
                      <CardDescription>Réponses aux questions les plus courantes</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="item-1">
                          <AccordionTrigger>Quels sont vos délais de réalisation pour un site web?</AccordionTrigger>
                          <AccordionContent>
                            Les délais varient en fonction de la complexité du projet. Pour un site vitrine, comptez
                            environ 3 à 4 semaines. Pour un site e-commerce ou une application plus complexe, les délais
                            peuvent s'étendre de 6 à 12 semaines.
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-2">
                          <AccordionTrigger>Comment se déroule un projet avec G&3M Technology?</AccordionTrigger>
                          <AccordionContent>
                            Notre processus de travail se déroule en plusieurs étapes : analyse des besoins, proposition
                            commerciale, conception, développement, tests et mise en production. Nous vous impliquons à
                            chaque étape pour garantir que le résultat final correspond parfaitement à vos attentes.
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-3">
                          <AccordionTrigger>
                            Proposez-vous des services de maintenance après la livraison?
                          </AccordionTrigger>
                          <AccordionContent>
                            Oui, nous proposons différentes formules de maintenance pour assurer le bon fonctionnement
                            de votre site ou application. Ces formules incluent les mises à jour de sécurité, les
                            sauvegardes régulières, les corrections de bugs et l'assistance technique.
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-4">
                          <AccordionTrigger>Quels sont vos tarifs?</AccordionTrigger>
                          <AccordionContent>
                            Nos tarifs varient en fonction de la nature et de la complexité de votre projet. Nous
                            établissons un devis personnalisé après avoir analysé précisément vos besoins. N'hésitez pas
                            à nous contacter pour obtenir une estimation gratuite.
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-5">
                          <AccordionTrigger>Travaillez-vous avec des entreprises à l'international?</AccordionTrigger>
                          <AccordionContent>
                            Oui, nous travaillons avec des clients du monde entier. Grâce aux outils de communication
                            modernes, nous pouvons collaborer efficacement quelle que soit votre localisation
                            géographique.
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
              <div className="aspect-video overflow-hidden rounded-lg">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63799.41051236168!2d29.18663566744386!3d-1.6828826999999954!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x19dd0a1950b0134d%3A0x3a7b8e18dabd9faa!2sGoma%2C%20Democratic%20Republic%20of%20the%20Congo!5e0!3m2!1sen!2sus!4v1710264845889!5m2!1sen!2sus"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Google Maps - Goma, RDC"
                  className="aspect-video"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

