import Image from "next/image"
import Link from "next/link"
import { ArrowRight, CheckCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/90 to-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px] opacity-10"></div>
        <div className="container px-4 md:px-6 relative z-10">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white">
                À propos de G&3M Technology
              </h1>
              <p className="max-w-[600px] text-white md:text-xl">
                Découvrez notre histoire, notre mission et les valeurs qui guident notre entreprise au quotidien.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary w-fit">
                  Notre Histoire
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Une passion pour l'innovation digitale
                </h2>
                <p className="text-muted-foreground md:text-xl">
                  Fondée en 2015, G&3M Technology est née de la vision de trois passionnés du digital souhaitant offrir
                  des solutions innovantes et accessibles aux entreprises de toutes tailles.
                </p>
              </div>
              <div className="space-y-4">
                <p className="text-muted-foreground">
                  Au fil des années, notre équipe s'est agrandie et nos compétences se sont diversifiées, nous
                  permettant d'accompagner nos clients dans tous les aspects de leur transformation digitale.
                </p>
                <p className="text-muted-foreground">
                  Aujourd'hui, G&3M Technology est reconnue pour son expertise, sa créativité et son approche centrée
                  sur les besoins spécifiques de chaque client. Nous sommes fiers d'avoir contribué au succès de plus de
                  200 entreprises à travers le monde.
                </p>
              </div>
            </div>
            <div className="flex justify-center lg:justify-end">
              <Image
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=550&h=550&q=80"
                alt="Notre Histoire - L'équipe G&3M Technology"
                width={550}
                height={550}
                className="rounded-lg object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Values Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">
                Mission & Valeurs
              </div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Ce qui nous définit</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Notre mission et nos valeurs guident chacune de nos actions et décisions.
              </p>
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:gap-12">
            <Card className="bg-background">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold">Notre Mission</h3>
                  <p className="text-muted-foreground">
                    Accompagner les entreprises dans leur transformation digitale en leur offrant des solutions
                    sur-mesure, innovantes et performantes qui répondent précisément à leurs besoins et contribuent à
                    leur croissance.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <p>Créer des expériences digitales exceptionnelles</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <p>Rendre les technologies avancées accessibles à tous</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <p>Contribuer au succès et à la croissance de nos clients</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-background">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold">Nos Valeurs</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-primary">Innovation</h4>
                      <p className="text-muted-foreground">
                        Nous explorons constamment de nouvelles technologies et approches pour offrir des solutions à la
                        pointe.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-primary">Excellence</h4>
                      <p className="text-muted-foreground">
                        Nous visons l'excellence dans chaque projet, avec une attention particulière aux détails et à la
                        qualité.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-primary">Collaboration</h4>
                      <p className="text-muted-foreground">
                        Nous croyons en la puissance du travail d'équipe et de la collaboration étroite avec nos
                        clients.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-primary">Intégrité</h4>
                      <p className="text-muted-foreground">
                        Nous agissons avec honnêteté, transparence et respect dans toutes nos interactions.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">Notre Équipe</div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Les talents derrière G&3M Technology</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Une équipe passionnée et expérimentée dédiée à la réussite de vos projets.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {[
              {
                name: "Thomas Martin",
                role: "CEO & Fondateur",
                bio: "Expert en stratégie digitale avec plus de 15 ans d'expérience dans le secteur tech.",
              },
              {
                name: "Sophie Dubois",
                role: "Directrice Marketing",
                bio: "Spécialiste SEO et marketing digital avec un parcours dans les plus grandes agences.",
              },
              {
                name: "Alexandre Chen",
                role: "Lead Developer",
                bio: "Développeur full-stack passionné par les technologies web et mobiles les plus récentes.",
              },
              {
                name: "Marie Leroy",
                role: "UI/UX Designer",
                bio: "Designer créative spécialisée dans la création d'interfaces intuitives et esthétiques.",
              },
              {
                name: "David Moreau",
                role: "Chef de Projet",
                bio: "Expert en gestion de projet agile avec une approche centrée sur les résultats.",
              },
              {
                name: "Camille Bernard",
                role: "Développeuse Front-end",
                bio: "Passionnée par l'accessibilité et les interfaces réactives.",
              },
              {
                name: "Lucas Petit",
                role: "Développeur Back-end",
                bio: "Spécialiste des architectures robustes et des bases de données performantes.",
              },
              {
                name: "Emma Roux",
                role: "Responsable Client",
                bio: "Dédiée à assurer une communication fluide et une satisfaction client optimale.",
              },
            ].map((member, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="aspect-square relative">
                  <Image
                    src={`https://randomuser.me/api/portraits/${index % 2 === 0 ? "men" : "women"}/${index + 1}.jpg`}
                    alt={member.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold">{member.name}</h3>
                  <p className="text-sm text-primary">{member.role}</p>
                  <p className="mt-2 text-sm text-muted-foreground">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Video Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">
                Présentation Vidéo
              </div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Découvrez G&3M Technology en vidéo</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Une immersion dans notre entreprise, notre culture et notre façon de travailler.
              </p>
            </div>
          </div>
          <div className="mx-auto max-w-4xl overflow-hidden rounded-lg shadow-lg">
            <div className="aspect-video">
              <iframe
                width="100%"
                height="100%"
                src="https://www.youtube.com/embed/jfKfPfyJRdk"
                title="Présentation G&3M Technology"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="aspect-video"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Prêt à collaborer avec nous?
              </h2>
              <p className="mx-auto max-w-[700px] text-primary-foreground/80 md:text-xl">
                Contactez-nous dès aujourd'hui pour discuter de votre projet et découvrir comment nous pouvons vous
                aider à atteindre vos objectifs.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild size="lg" variant="secondary">
                <Link href="/devis">
                  Demander un devis <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

