"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, CheckCircle, FileText, Send } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

export default function DevisPage() {
  const [formData, setFormData] = useState({
    company: "",
    name: "",
    email: "",
    phone: "",
    projectType: "",
    budget: "",
    deadline: "",
    description: "",
    services: {
      webDesign: false,
      webDevelopment: false,
      ecommerce: false,
      mobileApp: false,
      seo: false,
      socialMedia: false,
      contentCreation: false,
      other: false,
    },
    hearAbout: "",
  })

  const [step, setStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (service: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      services: {
        ...prev.services,
        [service]: checked,
      },
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setIsSuccess(true)
  }

  const nextStep = () => {
    setStep((prev) => prev + 1)
    window.scrollTo(0, 0)
  }

  const prevStep = () => {
    setStep((prev) => prev - 1)
    window.scrollTo(0, 0)
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/90 to-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px] opacity-10"></div>
        <div className="container px-4 md:px-6 relative z-10">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white">
                Demande de Devis
              </h1>
              <p className="max-w-[600px] text-white md:text-xl">
                Parlez-nous de votre projet et recevez un devis personnalisé pour concrétiser vos ambitions digitales.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Devis Form Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-12 lg:gap-12">
            {/* Form Column */}
            <div className="lg:col-span-8">
              {isSuccess ? (
                <Card className="border-green-200 bg-green-50">
                  <CardHeader>
                    <div className="flex items-center justify-center mb-4">
                      <div className="rounded-full bg-green-100 p-3">
                        <CheckCircle className="h-8 w-8 text-green-600" />
                      </div>
                    </div>
                    <CardTitle className="text-center text-2xl text-green-800">Demande envoyée avec succès!</CardTitle>
                    <CardDescription className="text-center text-green-700">
                      Merci pour votre demande de devis. Notre équipe l'examinera et vous contactera dans les 24-48
                      heures ouvrables.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col items-center space-y-4">
                      <p className="text-center text-muted-foreground">
                        Si vous avez des questions supplémentaires, n'hésitez pas à nous contacter directement.
                      </p>
                      <Button asChild>
                        <Link href="/">
                          Retour à l'accueil <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Formulaire de demande de devis</CardTitle>
                    <CardDescription>
                      Veuillez remplir ce formulaire avec les détails de votre projet pour recevoir un devis
                      personnalisé.
                    </CardDescription>
                    <div className="flex justify-between items-center mt-4">
                      <div className="flex items-center">
                        <div
                          className={`rounded-full h-8 w-8 flex items-center justify-center ${step >= 1 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
                        >
                          1
                        </div>
                        <div className={`h-1 w-8 ${step >= 2 ? "bg-primary" : "bg-muted"}`}></div>
                        <div
                          className={`rounded-full h-8 w-8 flex items-center justify-center ${step >= 2 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
                        >
                          2
                        </div>
                        <div className={`h-1 w-8 ${step >= 3 ? "bg-primary" : "bg-muted"}`}></div>
                        <div
                          className={`rounded-full h-8 w-8 flex items-center justify-center ${step >= 3 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
                        >
                          3
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground">Étape {step} sur 3</div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit}>
                      {step === 1 && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="company">Nom de l'entreprise</Label>
                            <Input
                              id="company"
                              name="company"
                              placeholder="Votre entreprise"
                              value={formData.company}
                              onChange={handleChange}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="name">Nom complet</Label>
                            <Input
                              id="name"
                              name="name"
                              placeholder="Votre nom"
                              required
                              value={formData.name}
                              onChange={handleChange}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="email">Email professionnel</Label>
                            <Input
                              id="email"
                              name="email"
                              type="email"
                              placeholder="votre.email@entreprise.com"
                              required
                              value={formData.email}
                              onChange={handleChange}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="phone">Téléphone</Label>
                            <Input
                              id="phone"
                              name="phone"
                              placeholder="+243 ..."
                              value={formData.phone}
                              onChange={handleChange}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Comment avez-vous entendu parler de nous?</Label>
                            <Select
                              value={formData.hearAbout}
                              onValueChange={(value) => handleSelectChange("hearAbout", value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionnez une option" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="search">Moteur de recherche</SelectItem>
                                <SelectItem value="social">Réseaux sociaux</SelectItem>
                                <SelectItem value="recommendation">Recommandation</SelectItem>
                                <SelectItem value="event">Événement</SelectItem>
                                <SelectItem value="other">Autre</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex justify-end mt-6">
                            <Button type="button" onClick={nextStep}>
                              Suivant <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )}

                      {step === 2 && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label>Type de projet</Label>
                            <RadioGroup
                              value={formData.projectType}
                              onValueChange={(value) => handleSelectChange("projectType", value)}
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="website" id="website" />
                                <Label htmlFor="website">Site web</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="ecommerce" id="ecommerce" />
                                <Label htmlFor="ecommerce">E-commerce</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="mobile" id="mobile" />
                                <Label htmlFor="mobile">Application mobile</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="marketing" id="marketing" />
                                <Label htmlFor="marketing">Marketing digital</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="other" id="other" />
                                <Label htmlFor="other">Autre</Label>
                              </div>
                            </RadioGroup>
                          </div>
                          <div className="space-y-2">
                            <Label>Services requis (sélectionnez tous ceux qui s'appliquent)</Label>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              <div className="flex items-center space-x-2">
                                <Checkbox
                                  id="webDesign"
                                  checked={formData.services.webDesign}
                                  onCheckedChange={(checked) => handleCheckboxChange("webDesign", checked as boolean)}
                                />
                                <Label htmlFor="webDesign">Design web</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox
                                  id="webDevelopment"
                                  checked={formData.services.webDevelopment}
                                  onCheckedChange={(checked) =>
                                    handleCheckboxChange("webDevelopment", checked as boolean)
                                  }
                                />
                                <Label htmlFor="webDevelopment">Développement web</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox
                                  id="ecommerce"
                                  checked={formData.services.ecommerce}
                                  onCheckedChange={(checked) => handleCheckboxChange("ecommerce", checked as boolean)}
                                />
                                <Label htmlFor="ecommerce">E-commerce</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox
                                  id="mobileApp"
                                  checked={formData.services.mobileApp}
                                  onCheckedChange={(checked) => handleCheckboxChange("mobileApp", checked as boolean)}
                                />
                                <Label htmlFor="mobileApp">Application mobile</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox
                                  id="seo"
                                  checked={formData.services.seo}
                                  onCheckedChange={(checked) => handleCheckboxChange("seo", checked as boolean)}
                                />
                                <Label htmlFor="seo">SEO / Référencement</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox
                                  id="socialMedia"
                                  checked={formData.services.socialMedia}
                                  onCheckedChange={(checked) => handleCheckboxChange("socialMedia", checked as boolean)}
                                />
                                <Label htmlFor="socialMedia">Réseaux sociaux</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox
                                  id="contentCreation"
                                  checked={formData.services.contentCreation}
                                  onCheckedChange={(checked) =>
                                    handleCheckboxChange("contentCreation", checked as boolean)
                                  }
                                />
                                <Label htmlFor="contentCreation">Création de contenu</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox
                                  id="other"
                                  checked={formData.services.other}
                                  onCheckedChange={(checked) => handleCheckboxChange("other", checked as boolean)}
                                />
                                <Label htmlFor="other">Autre</Label>
                              </div>
                            </div>
                          </div>
                          <div className="flex justify-between mt-6">
                            <Button type="button" variant="outline" onClick={prevStep}>
                              Précédent
                            </Button>
                            <Button type="button" onClick={nextStep}>
                              Suivant <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )}

                      {step === 3 && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="budget">Budget approximatif (USD)</Label>
                            <Select
                              value={formData.budget}
                              onValueChange={(value) => handleSelectChange("budget", value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionnez une fourchette de budget" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="less-1000">Moins de 1 000 $</SelectItem>
                                <SelectItem value="1000-3000">1 000 $ - 3 000 $</SelectItem>
                                <SelectItem value="3000-5000">3 000 $ - 5 000 $</SelectItem>
                                <SelectItem value="5000-10000">5 000 $ - 10 000 $</SelectItem>
                                <SelectItem value="10000-plus">Plus de 10 000 $</SelectItem>
                                <SelectItem value="not-sure">Je ne sais pas encore</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="deadline">Délai souhaité</Label>
                            <Select
                              value={formData.deadline}
                              onValueChange={(value) => handleSelectChange("deadline", value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionnez un délai" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="urgent">Urgent (moins d'un mois)</SelectItem>
                                <SelectItem value="1-2-months">1-2 mois</SelectItem>
                                <SelectItem value="3-6-months">3-6 mois</SelectItem>
                                <SelectItem value="6-plus-months">Plus de 6 mois</SelectItem>
                                <SelectItem value="not-sure">Flexible / Je ne sais pas encore</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="description">Description détaillée du projet</Label>
                            <Textarea
                              id="description"
                              name="description"
                              placeholder="Décrivez votre projet, vos objectifs, vos attentes et toute information pertinente qui nous aidera à comprendre vos besoins."
                              className="min-h-[150px]"
                              value={formData.description}
                              onChange={handleChange}
                              required
                            />
                          </div>
                          <div className="flex justify-between mt-6">
                            <Button type="button" variant="outline" onClick={prevStep}>
                              Précédent
                            </Button>
                            <Button type="submit" disabled={isSubmitting}>
                              {isSubmitting ? (
                                "Envoi en cours..."
                              ) : (
                                <>
                                  Envoyer la demande <Send className="ml-2 h-4 w-4" />
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      )}
                    </form>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Info Column */}
            <div className="lg:col-span-4 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Pourquoi nous choisir?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold">Expertise</h3>
                      <p className="text-sm text-muted-foreground">
                        Plus de 8 ans d'expérience dans le développement de solutions digitales.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold">Solutions sur-mesure</h3>
                      <p className="text-sm text-muted-foreground">
                        Chaque projet est unique et mérite une approche personnalisée.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold">Support continu</h3>
                      <p className="text-sm text-muted-foreground">
                        Nous vous accompagnons avant, pendant et après la réalisation de votre projet.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold">Résultats mesurables</h3>
                      <p className="text-sm text-muted-foreground">
                        Nous nous engageons à fournir des résultats concrets et mesurables.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Notre processus</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="rounded-full bg-primary/10 h-6 w-6 flex items-center justify-center text-primary font-medium shrink-0">
                      1
                    </div>
                    <div>
                      <h3 className="font-semibold">Consultation initiale</h3>
                      <p className="text-sm text-muted-foreground">
                        Nous discutons de vos besoins et objectifs pour comprendre votre vision.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="rounded-full bg-primary/10 h-6 w-6 flex items-center justify-center text-primary font-medium shrink-0">
                      2
                    </div>
                    <div>
                      <h3 className="font-semibold">Proposition et devis</h3>
                      <p className="text-sm text-muted-foreground">
                        Nous élaborons une proposition détaillée avec un devis transparent.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="rounded-full bg-primary/10 h-6 w-6 flex items-center justify-center text-primary font-medium shrink-0">
                      3
                    </div>
                    <div>
                      <h3 className="font-semibold">Conception et développement</h3>
                      <p className="text-sm text-muted-foreground">
                        Notre équipe conçoit et développe votre solution avec des points de validation réguliers.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="rounded-full bg-primary/10 h-6 w-6 flex items-center justify-center text-primary font-medium shrink-0">
                      4
                    </div>
                    <div>
                      <h3 className="font-semibold">Lancement et suivi</h3>
                      <p className="text-sm text-muted-foreground">
                        Nous lançons votre projet et assurons un suivi pour garantir son succès.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="rounded-lg overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=300&q=80"
                  alt="Équipe G&3M Technology en réunion"
                  width={500}
                  height={300}
                  className="w-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="w-full py-12 md:py-24 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">Témoignages</div>
              <h2 className="text-3xl font-bold tracking-tighter">Ce que disent nos clients</h2>
              <p className="max-w-[900px] text-muted-foreground">
                Découvrez les retours de nos clients satisfaits sur nos services et notre collaboration.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="rounded-full bg-primary/10 p-2">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Processus de devis clair et efficace</h3>
                      <p className="text-sm text-muted-foreground">Sophie M., Directrice Marketing</p>
                    </div>
                  </div>
                  <p className="text-muted-foreground">
                    "Le processus de demande de devis était simple et transparent. L'équipe a pris le temps de
                    comprendre nos besoins et nous a fourni une proposition détaillée qui répondait parfaitement à nos
                    attentes."
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="rounded-full bg-primary/10 p-2">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Excellent rapport qualité-prix</h3>
                      <p className="text-sm text-muted-foreground">Thomas D., CEO</p>
                    </div>
                  </div>
                  <p className="text-muted-foreground">
                    "Le devis proposé par G&3M Technology offrait un excellent rapport qualité-prix. Ils ont su nous
                    proposer des solutions adaptées à notre budget tout en maintenant un haut niveau de qualité."
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="rounded-full bg-primary/10 p-2">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Réactivité et professionnalisme</h3>
                      <p className="text-sm text-muted-foreground">Marie L., Fondatrice</p>
                    </div>
                  </div>
                  <p className="text-muted-foreground">
                    "J'ai reçu un devis détaillé en moins de 48h après ma demande. L'équipe a fait preuve d'un grand
                    professionnalisme et a su répondre à toutes mes questions avec précision."
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="w-full py-12 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">FAQ</div>
              <h2 className="text-3xl font-bold tracking-tighter">Questions fréquentes</h2>
              <p className="max-w-[900px] text-muted-foreground">
                Réponses aux questions les plus courantes concernant nos devis et notre processus de travail.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Comment est calculé le prix d'un projet?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Le prix est calculé en fonction de la complexité du projet, des fonctionnalités requises, des délais
                  et des ressources nécessaires. Nous proposons des tarifs transparents et adaptés à chaque projet.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Combien de temps faut-il pour recevoir un devis?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Nous nous engageons à vous fournir un devis détaillé dans un délai de 2 à 5 jours ouvrables après
                  réception de votre demande complète.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Le devis est-il gratuit?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Oui, l'établissement du devis est totalement gratuit et sans engagement. Nous croyons en la
                  transparence et souhaitons vous fournir toutes les informations nécessaires pour prendre votre
                  décision.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Que se passe-t-il après l'acceptation du devis?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Après acceptation du devis, nous établissons un contrat détaillant les termes du projet. Nous
                  organisons ensuite une réunion de lancement pour définir les étapes clés et commencer le travail.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}

