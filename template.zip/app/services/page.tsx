import Link from "next/link"
import Image from "next/image"
import {
  ArrowRight,
  CheckCircle,
  Globe,
  Laptop,
  BarChart,
  Users,
  ShieldCheck,
  Smartphone,
  Database,
  LineChart,
  ShoppingCart,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ServicesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-primary/90 to-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px] opacity-10"></div>
        <div className="container px-4 md:px-6 relative z-10">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white">
                Nos Services
              </h1>
              <p className="max-w-[600px] text-white md:text-xl">
                Des solutions digitales complètes pour répondre à tous vos besoins et transformer votre présence en
                ligne.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Marketing Digital Section */}
      <section id="marketing" className="w-full py-12 md:py-24 lg:py-32 bg-background scroll-mt-20">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary w-fit">
                Marketing Digital
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Boostez votre visibilité en ligne
                </h2>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  Nos stratégies de marketing digital sont conçues pour augmenter votre visibilité, attirer plus de
                  clients et générer des résultats mesurables.
                </p>
              </div>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Référencement naturel (SEO)</h3>
                    <p className="text-muted-foreground">
                      Améliorez votre positionnement sur les moteurs de recherche et augmentez votre trafic organique.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Publicité en ligne (SEA)</h3>
                    <p className="text-muted-foreground">
                      Campagnes publicitaires ciblées sur Google, Facebook, Instagram et LinkedIn pour des résultats
                      immédiats.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Gestion des réseaux sociaux</h3>
                    <p className="text-muted-foreground">
                      Création de contenu engageant et gestion de vos profils sociaux pour renforcer votre communauté.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Email marketing</h3>
                    <p className="text-muted-foreground">
                      Campagnes d'emailing personnalisées pour fidéliser vos clients et générer des ventes récurrentes.
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <Button asChild size="lg">
                  <Link href="/contact">
                    Demander un devis <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
            <div className="flex justify-center lg:justify-end">
              <Image
                src="https://images.unsplash.com/photo-1533750349088-cd871a92f312?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=550&h=550&q=80"
                alt="Marketing Digital Strategy"
                width={550}
                height={550}
                className="rounded-lg object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Conception Web Section */}
      <section id="web" className="w-full py-12 md:py-24 lg:py-32 bg-muted/50 scroll-mt-20">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex justify-center lg:justify-start order-2 lg:order-1">
              <Image
                src="https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=550&h=550&q=80"
                alt="Web Design and Development"
                width={550}
                height={550}
                className="rounded-lg object-cover"
              />
            </div>
            <div className="flex flex-col justify-center space-y-4 order-1 lg:order-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary w-fit">
                Conception Web
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Sites web professionnels et performants
                </h2>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  Nous créons des sites web sur-mesure qui reflètent votre identité, optimisés pour convertir vos
                  visiteurs en clients.
                </p>
              </div>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Sites vitrines</h3>
                    <p className="text-muted-foreground">
                      Présentez votre entreprise avec élégance et professionnalisme pour renforcer votre crédibilité.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">E-commerce</h3>
                    <p className="text-muted-foreground">
                      Boutiques en ligne performantes avec gestion des stocks, paiements sécurisés et expérience d'achat
                      optimisée.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Refonte de sites</h3>
                    <p className="text-muted-foreground">
                      Modernisez votre site existant pour améliorer ses performances et son expérience utilisateur.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Design responsive</h3>
                    <p className="text-muted-foreground">
                      Sites parfaitement adaptés à tous les appareils (ordinateurs, tablettes, smartphones).
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <Button asChild size="lg">
                  <Link href="/contact">
                    Demander un devis <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Développement Logiciel Section */}
      <section id="software" className="w-full py-12 md:py-24 lg:py-32 bg-background scroll-mt-20">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary w-fit">
                Développement Logiciel
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Solutions logicielles sur-mesure
                </h2>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  Nous développons des applications web et mobiles personnalisées pour répondre précisément à vos
                  besoins métier.
                </p>
              </div>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Applications web</h3>
                    <p className="text-muted-foreground">
                      Applications métier accessibles depuis n'importe quel navigateur, avec des interfaces intuitives.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Applications mobiles</h3>
                    <p className="text-muted-foreground">
                      Applications iOS et Android natives ou hybrides pour une expérience utilisateur optimale.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Solutions métier (ERP, CRM)</h3>
                    <p className="text-muted-foreground">
                      Outils de gestion personnalisés pour optimiser vos processus internes et votre relation client.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold">Intégration API</h3>
                    <p className="text-muted-foreground">
                      Connexion de vos systèmes existants avec de nouvelles solutions pour une gestion unifiée.
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <Button asChild size="lg">
                  <Link href="/contact">
                    Demander un devis <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
            <div className="flex justify-center lg:justify-end">
              <Image
                src="https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=550&h=550&q=80"
                alt="Software Development Team"
                width={550}
                height={550}
                className="rounded-lg object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* All Services Grid */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Tous nos services</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Découvrez l'ensemble de nos services digitaux pour transformer votre présence en ligne et optimiser
                votre activité.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-12">
            {[
              {
                icon: <Globe className="h-10 w-10 text-primary" />,
                title: "SEO",
                description: "Optimisation pour les moteurs de recherche pour améliorer votre visibilité organique.",
              },
              {
                icon: <BarChart className="h-10 w-10 text-primary" />,
                title: "SEA",
                description: "Campagnes publicitaires ciblées sur Google et autres plateformes.",
              },
              {
                icon: <Users className="h-10 w-10 text-primary" />,
                title: "Réseaux Sociaux",
                description: "Gestion de vos profils et création de contenu engageant.",
              },
              {
                icon: <Laptop className="h-10 w-10 text-primary" />,
                title: "Sites Vitrines",
                description: "Sites professionnels pour présenter votre entreprise et vos services.",
              },
              {
                icon: <ShoppingCart className="h-10 w-10 text-primary" />,
                title: "E-commerce",
                description: "Boutiques en ligne performantes avec gestion des stocks et paiements sécurisés.",
              },
              {
                icon: <LineChart className="h-10 w-10 text-primary" />,
                title: "Analytics",
                description: "Suivi et analyse de vos performances digitales pour optimiser vos stratégies.",
              },
              {
                icon: <Smartphone className="h-10 w-10 text-primary" />,
                title: "Applications Mobiles",
                description:
                  "Applications iOS et Android natives ou hybrides pour une expérience utilisateur optimale.",
              },
              {
                icon: <Database className="h-10 w-10 text-primary" />,
                title: "ERP & CRM",
                description: "Solutions de gestion personnalisées pour optimiser vos processus internes.",
              },
              {
                icon: <ShieldCheck className="h-10 w-10 text-primary" />,
                title: "Sécurité Web",
                description: "Protection de vos données et de vos systèmes contre les menaces en ligne.",
              },
            ].map((service, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="flex justify-center mb-2">{service.icon}</div>
                  <CardTitle>{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Prêt à transformer votre présence digitale?
              </h2>
              <p className="mx-auto max-w-[700px] text-primary-foreground/80 md:text-xl">
                Contactez-nous dès aujourd'hui pour discuter de votre projet et obtenir un devis personnalisé.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild size="lg" variant="secondary">
                <Link href="/contact">Nous contacter</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

