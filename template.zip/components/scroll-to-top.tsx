"use client"

import { useEffect } from "react"
import { usePathname } from "next/navigation"

export function ScrollToTop() {
  const pathname = usePathname()

  useEffect(() => {
    // Remettre le scroll en haut de la page à chaque changement de route
    window.scrollTo(0, 0)
  }, [pathname])

  return null
}

