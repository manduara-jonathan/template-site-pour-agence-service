"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Package2, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

import { useRouter } from "next/navigation"

export function SiteHeader() {
  const [isOpen, setIsOpen] = useState(false)
  const router = useRouter()

  // Fonction pour gérer le défilement fluide
  const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    // Si c'est un lien avec ancre (#) et que nous sommes sur la bonne page
    if (href.includes("#")) {
      const pagePath = href.split("#")[0]
      const currentPath = window.location.pathname

      // Si nous sommes déjà sur la bonne page ou si c'est juste une ancre
      if (pagePath === "" || pagePath === currentPath) {
        e.preventDefault()

        // Extraire l'ID de l'ancre
        const targetId = href.split("#")[1]
        const targetElement = document.getElementById(targetId)

        if (targetElement) {
          // Fermer le menu mobile si ouvert
          setIsOpen(false)

          // Calculer la position en tenant compte du header fixe
          const headerOffset = 80 // Hauteur approximative du header
          const elementPosition = targetElement.getBoundingClientRect().top
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset

          // Défilement fluide
          window.scrollTo({
            top: offsetPosition,
            behavior: "smooth",
          })
        }
      } else {
        // Si nous devons naviguer vers une autre page, laissez le comportement par défaut
        // Le ScrollToTop s'occupera de remettre le scroll en haut
      }
    }
  }

  return (
    <header className="fixed top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
      <div className="container flex h-16 items-center">
        <Link href="/" className="flex items-center space-x-2 mr-6">
          <Package2 className="h-6 w-6 text-primary" />
          <span className="font-bold text-xl hidden sm:inline-block">Votre Entreprise</span>
          <span className="font-bold text-xl sm:hidden">Votre E.</span>
        </Link>
        <div className="hidden lg:flex flex-1">
          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <Link href="/" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Accueil</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/about" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>À propos</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Services</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                    {[
                      {
                        title: "Marketing Digital",
                        href: "/services#marketing",
                        description: "SEO, publicité en ligne, réseaux sociaux et email marketing.",
                      },
                      {
                        title: "Conception Web",
                        href: "/services#web",
                        description: "Sites vitrines, e-commerce et refonte de sites existants.",
                      },
                      {
                        title: "Développement Logiciel",
                        href: "/services#software",
                        description: "Applications web et mobiles, ERP, CRM et solutions sur-mesure.",
                      },
                      {
                        title: "Tous nos services",
                        href: "/services",
                        description: "Découvrez l'ensemble de nos services digitaux.",
                      },
                    ].map((service) => (
                      <li key={service.title}>
                        <NavigationMenuLink asChild>
                          <Link
                            href={service.href}
                            className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                            onClick={(e) => service.href.includes("#") && handleSmoothScroll(e, service.href)}
                          >
                            <div className="text-sm font-medium leading-none">{service.title}</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              {service.description}
                            </p>
                          </Link>
                        </NavigationMenuLink>
                      </li>
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/portfolio" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Portfolio</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/blog" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Blog</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/contact" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Contact</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>
        <div className="hidden lg:flex ml-auto">
          <Button asChild>
            <Link href="/contact">Demander un devis</Link>
          </Button>
        </div>
        <div className="lg:hidden ml-auto">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              {/* Menu mobile */}
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

